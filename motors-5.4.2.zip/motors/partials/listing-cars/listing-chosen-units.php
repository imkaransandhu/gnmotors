<?php
	$stm_listing_filter = stm_get_filter();
	$filter_badges = $stm_listing_filter['badges'];
?>
